<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body, html {
  height: 100%;
  margin: 0;
}

.paragraph1 {
  color: white;
  background-color: #003d99;
}
</style>
	<title>Blood Donors Management System</title>
  <link rel="icon" href="img/blood.png" type="image/png" sizes="20x20">
	<link rel="stylesheet" href="style.css">
	<link rel="stylesheet" a href="bootstrap.css">
	<link rel="stylesheet" a href="tab.css">
</head>
<body style="background-color:#e6e6ff">
<div class="bg"></div>
<center><p class="paragraph1" style="background-color: #003d99">Copyright EDonatelife System; 2024</center></p>
</body>
</html>
<script src="js/script.js"></script>